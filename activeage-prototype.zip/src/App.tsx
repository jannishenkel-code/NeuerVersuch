import React, { useState } from 'react';
import { Heart, Home, BookOpen, User, Play, Clock, Trophy, Volume2, Users, MapPin, Car, MessageCircle, AlertCircle, Phone, Cloud, Calendar, Video, Image, Mic, UserPlus, Share2, Award, Apple, Map, Coffee, Gift } from 'lucide-react';

export default function ActiveAgeApp() {
  const [currentView, setCurrentView] = useState('home');
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [completedExercises, setCompletedExercises] = useState([]);
  const [streak, setStreak] = useState(3);
  const [selectedPost, setSelectedPost] = useState(null);
  const [showEmergency, setShowEmergency] = useState(false);
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);
  const [showShareProgress, setShowShareProgress] = useState(false);
  const [selectedCafe, setSelectedCafe] = useState(null);
  const [rewardPoints, setRewardPoints] = useState(45);

  const exercises = [
    {
      id: 1,
      title: 'Gleichgewichtsübung',
      category: 'Balance',
      duration: '5 Min',
      difficulty: 'Leicht',
      description: 'Verbessern Sie Ihr Gleichgewicht und beugen Sie Stürzen vor.',
      steps: [
        'Stellen Sie sich hinter einen stabilen Stuhl',
        'Halten Sie sich am Stuhl fest',
        'Heben Sie ein Bein langsam an (10 Sekunden halten)',
        'Wechseln Sie das Bein',
        'Wiederholen Sie 5x pro Seite'
      ],
      benefits: 'Sturzprävention, bessere Körperkontrolle'
    },
    {
      id: 2,
      title: 'Sitzende Armkreise',
      category: 'Mobilität',
      duration: '3 Min',
      difficulty: 'Sehr leicht',
      description: 'Lockern Sie Ihre Schultern und verbessern Sie die Beweglichkeit.',
      steps: [
        'Setzen Sie sich aufrecht auf einen Stuhl',
        'Strecken Sie beide Arme zur Seite aus',
        'Machen Sie langsame Kreise vorwärts (10x)',
        'Dann Kreise rückwärts (10x)',
        'Atmen Sie dabei ruhig weiter'
      ],
      benefits: 'Schulterflexibilität, Durchblutung'
    }
  ];

  const nearbyCafes = [
    {
      id: 1,
      name: 'Café Sonnenschein',
      distance: '350m vom Stadtgarten',
      rating: 4.8,
      speciality: 'Hausgemachter Apfelkuchen',
      discount: '10% Rabatt mit ActiveAge',
      emoji: '☕',
      address: 'Hauptstraße 24',
      nearActivity: 'Nordic Walking Gruppe',
      atmosphere: 'Gemütlich & barrierefrei',
      points: 10
    },
    {
      id: 2,
      name: 'Bäckerei Müller',
      distance: '200m von der Schwimmhalle',
      rating: 4.6,
      speciality: 'Frische Obsttorte',
      discount: 'Gratis Kaffee ab 5 Besuchen',
      emoji: '🥐',
      address: 'Schwimmbadweg 12',
      nearActivity: 'Aqua-Fitness',
      atmosphere: 'Traditionell & freundlich',
      points: 10
    }
  ];

  const achievements = [
    { id: 1, title: '3-Tage Streak', icon: '🔥', unlocked: true, description: '3 Tage in Folge trainiert' },
    { id: 2, title: 'Erste Übung', icon: '🎯', unlocked: true, description: 'Erste Übung abgeschlossen' },
    { id: 3, title: '7-Tage Streak', icon: '⭐', unlocked: false, description: 'Noch 4 Tage bis zum Ziel!' }
  ];

  const rewardTiers = [
    { points: 10, reward: 'Gratis Kaffee', icon: '☕', claimed: true },
    { points: 25, reward: 'Stück Kuchen', icon: '🍰', claimed: true },
    { points: 50, reward: 'Café-Gutschein 10€', icon: '🎁', claimed: false }
  ];

  const markComplete = (exerciseId) => {
    if (!completedExercises.includes(exerciseId)) {
      setCompletedExercises([...completedExercises, exerciseId]);
    }
  };

  const HomeView = () => (
    <div className="p-6 space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-3xl p-8 text-white">
        <h1 className="text-4xl font-bold mb-3">Hallo! 👋</h1>
        <p className="text-2xl mb-6">Schön, dass Sie da sind!</p>
        <div className="flex items-center gap-4 bg-white/20 rounded-2xl p-4">
          <Trophy className="w-12 h-12" />
          <div>
            <p className="text-xl font-semibold">{streak} Tage Streak! 🔥</p>
            <p className="text-lg">Großartig gemacht!</p>
          </div>
        </div>
      </div>

      <button
        onClick={() => setShowEmergency(true)}
        className="w-full bg-red-500 hover:bg-red-600 text-white rounded-3xl p-6 flex items-center justify-center gap-4 transition-all shadow-lg"
      >
        <AlertCircle className="w-16 h-16" />
        <div className="text-left">
          <p className="text-3xl font-bold">NOTFALL</p>
          <p className="text-xl">Hilfe rufen</p>
        </div>
      </button>

      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => setCurrentView('exercises')}
          className="bg-blue-500 hover:bg-blue-600 text-white rounded-3xl p-8 flex flex-col items-center justify-center gap-3 transition-all"
        >
          <Play className="w-16 h-16" />
          <span className="text-2xl font-bold">Übungen</span>
        </button>
        <button
          onClick={() => setShowVideoCall(true)}
          className="bg-green-500 hover:bg-green-600 text-white rounded-3xl p-8 flex flex-col items-center justify-center gap-3 transition-all"
        >
          <Video className="w-16 h-16" />
          <span className="text-2xl font-bold">Video-Anruf</span>
        </button>
      </div>

      <button
        onClick={() => setCurrentView('rewards')}
        className="w-full bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-500 hover:to-orange-500 text-white rounded-3xl p-6 flex items-center gap-4 transition-all relative"
      >
        <Gift className="w-16 h-16" />
        <div className="flex-1 text-left">
          <p className="text-3xl font-bold">Belohnungen</p>
          <p className="text-xl">Sie haben {rewardPoints} Punkte! ☕</p>
        </div>
        <div className="absolute top-2 right-2 bg-red-500 text-white px-3 py-1 rounded-full text-lg font-bold">
          NEU
        </div>
      </button>
    </div>
  );

  const ExercisesView = () => (
    <div className="p-6 space-y-4">
      <h1 className="text-4xl font-bold mb-6">Ihre Übungen</h1>
      {exercises.map(exercise => (
        <button
          key={exercise.id}
          onClick={() => {
            setSelectedExercise(exercise);
            setCurrentView('detail');
          }}
          className="w-full bg-white border-4 border-gray-200 rounded-3xl p-6 text-left hover:border-blue-400 transition-all"
        >
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-3xl font-bold text-gray-800">{exercise.title}</h3>
            {completedExercises.includes(exercise.id) && (
              <span className="text-4xl">✓</span>
            )}
          </div>
          <p className="text-2xl text-gray-600">{exercise.description}</p>
        </button>
      ))}
    </div>
  );

  const ExerciseDetailView = () => (
    <div className="p-6 space-y-6">
      <button
        onClick={() => setCurrentView('exercises')}
        className="text-3xl text-blue-600 font-semibold mb-4"
      >
        ← Zurück
      </button>
      
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-3xl p-8 text-white">
        <h1 className="text-4xl font-bold mb-4">{selectedExercise.title}</h1>
        <p className="text-2xl">{selectedExercise.duration} • {selectedExercise.difficulty}</p>
      </div>

      <div className="bg-white border-4 border-gray-200 rounded-3xl p-6">
        <h2 className="text-3xl font-bold mb-4">📋 So geht's:</h2>
        <ol className="space-y-4">
          {selectedExercise.steps.map((step, index) => (
            <li key={index} className="flex gap-4">
              <span className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold flex-shrink-0">
                {index + 1}
              </span>
              <p className="text-2xl text-gray-800 pt-2">{step}</p>
            </li>
          ))}
        </ol>
      </div>

      <button
        onClick={() => {
          markComplete(selectedExercise.id);
          setCurrentView('exercises');
        }}
        className="w-full bg-green-500 hover:bg-green-600 text-white text-3xl font-bold py-6 rounded-3xl transition-all"
      >
        ✓ Übung abschließen
      </button>
    </div>
  );

  const RewardsView = () => (
    <div className="p-6 space-y-6">
      <button
        onClick={() => setCurrentView('home')}
        className="text-3xl text-blue-600 font-semibold mb-4"
      >
        ← Zurück
      </button>

      <div className="bg-gradient-to-r from-amber-400 to-orange-400 rounded-3xl p-8 text-white text-center">
        <Gift className="w-20 h-20 mx-auto mb-4" />
        <h1 className="text-4xl font-bold mb-3">Belohnungen</h1>
        <p className="text-5xl font-bold mb-2">{rewardPoints} Punkte</p>
      </div>

      <div className="bg-white border-4 border-gray-200 rounded-3xl p-6">
        <h2 className="text-3xl font-bold mb-4">Ihre Prämien</h2>
        <div className="space-y-3">
          {rewardTiers.map((tier, index) => (
            <div 
              key={index}
              className={`rounded-2xl p-5 border-4 ${
                tier.claimed 
                  ? 'bg-green-50 border-green-300' 
                  : rewardPoints >= tier.points 
                    ? 'bg-amber-50 border-amber-300' 
                    : 'bg-gray-100 border-gray-300 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="text-5xl">{tier.icon}</span>
                  <div>
                    <p className="text-2xl font-bold">{tier.reward}</p>
                    <p className="text-xl text-gray-600">{tier.points} Punkte</p>
                  </div>
                </div>
                {tier.claimed && <span className="text-3xl">✓</span>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => setCurrentView('cafe-map')}
        className="w-full bg-gradient-to-r from-brown-400 to-amber-600 text-white rounded-3xl p-6 flex items-center justify-center gap-4 transition-all"
        style={{ background: 'linear-gradient(to right, #8B4513, #D2691E)' }}
      >
        <Map className="w-16 h-16" />
        <div className="text-left">
          <p className="text-3xl font-bold">Café-Finder</p>
          <p className="text-xl">Cafés entdecken</p>
        </div>
      </button>
    </div>
  );

  const CafeMapView = () => (
    <div className="p-6 space-y-6">
      <button
        onClick={() => setCurrentView('rewards')}
        className="text-3xl text-blue-600 font-semibold mb-4"
      >
        ← Zurück
      </button>

      <div className="bg-gradient-to-r from-brown-400 to-amber-600 rounded-3xl p-8 text-white text-center" style={{ background: 'linear-gradient(to right, #8B4513, #D2691E)' }}>
        <Coffee className="w-20 h-20 mx-auto mb-4" />
        <h1 className="text-4xl font-bold mb-3">Café-Finder</h1>
        <p className="text-2xl">Gemütliche Orte in Ihrer Nähe</p>
      </div>

      <div className="bg-white border-4 border-gray-300 rounded-3xl p-6 h-64 flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100"></div>
        <div className="relative z-10 text-center">
          <Map className="w-20 h-20 mx-auto mb-3 text-gray-600" />
          <p className="text-2xl font-bold text-gray-700">Interaktive Karte</p>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-3xl font-bold">Cafés in Ihrer Nähe</h2>
        {nearbyCafes.map(cafe => (
          <button
            key={cafe.id}
            onClick={() => {
              setSelectedCafe(cafe);
              setCurrentView('cafe-detail');
            }}
            className="w-full bg-white border-4 border-gray-200 rounded-3xl p-6 text-left hover:border-amber-400 transition-all"
          >
            <div className="flex items-start gap-4 mb-3">
              <span className="text-5xl">{cafe.emoji}</span>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-800 mb-1">{cafe.name}</h3>
                <p className="text-xl text-gray-600 mb-2">⭐ {cafe.rating}</p>
                <p className="text-xl text-blue-600">🎯 Nach: {cafe.nearActivity}</p>
              </div>
            </div>
            
            <div className="bg-amber-50 rounded-2xl p-4 border-2 border-amber-200">
              <p className="text-xl font-bold text-amber-900">🎁 {cafe.discount}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );

  const CafeDetailView = () => (
    <div className="p-6 space-y-6">
      <button
        onClick={() => setCurrentView('cafe-map')}
        className="text-3xl text-blue-600 font-semibold mb-4"
      >
        ← Zurück
      </button>

      <div className="bg-gradient-to-r from-brown-400 to-amber-600 rounded-3xl p-8 text-white" style={{ background: 'linear-gradient(to right, #8B4513, #D2691E)' }}>
        <span className="text-7xl mb-4 block">{selectedCafe.emoji}</span>
        <h1 className="text-4xl font-bold mb-2">{selectedCafe.name}</h1>
        <p className="text-3xl">⭐ {selectedCafe.rating}</p>
      </div>

      <div className="bg-white border-4 border-gray-200 rounded-3xl p-6">
        <h2 className="text-3xl font-bold mb-4">📍 Standort</h2>
        <p className="text-2xl text-gray-700 mb-2">{selectedCafe.address}</p>
        <p className="text-xl text-gray-600">{selectedCafe.distance}</p>
      </div>

      <div className="bg-amber-50 border-4 border-amber-200 rounded-3xl p-6">
        <h2 className="text-3xl font-bold text-amber-900 mb-4">🎁 Ihr Vorteil</h2>
        <p className="text-2xl text-amber-800 font-bold">{selectedCafe.discount}</p>
      </div>

      <div className="bg-green-50 border-4 border-green-200 rounded-3xl p-6">
        <h2 className="text-3xl font-bold text-green-800 mb-4">👥 Soziale Komponente</h2>
        <p className="text-2xl text-green-900">
          Treffen Sie Ihre Trainingspartner nach der Aktivität zum gemütlichen Beisammensein!
        </p>
      </div>

      <button className="w-full bg-green-500 hover:bg-green-600 text-white text-2xl font-bold py-6 rounded-3xl transition-all">
        👥 Gruppe einladen
      </button>
    </div>
  );

  const ProfileView = () => (
    <div className="p-6 space-y-6">
      <h1 className="text-4xl font-bold mb-6">Ihr Profil</h1>
      
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl p-8 text-white text-center">
        <div className="w-32 h-32 bg-white rounded-full mx-auto mb-4 flex items-center justify-center">
          <User className="w-20 h-20 text-purple-500" />
        </div>
        <h2 className="text-3xl font-bold mb-2">Aktiver Nutzer</h2>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 border-4 border-blue-200 rounded-3xl p-6 text-center">
          <Trophy className="w-16 h-16 text-blue-600 mx-auto mb-3" />
          <p className="text-5xl font-bold text-blue-600 mb-2">{streak}</p>
          <p className="text-2xl text-blue-800">Tage Streak</p>
        </div>
        <div className="bg-amber-50 border-4 border-amber-200 rounded-3xl p-6 text-center">
          <Gift className="w-16 h-16 text-amber-600 mx-auto mb-3" />
          <p className="text-5xl font-bold text-amber-600 mb-2">{rewardPoints}</p>
          <p className="text-2xl text-amber-800">Punkte</p>
        </div>
      </div>

      <button
        onClick={() => setShowAchievements(true)}
        className="w-full bg-yellow-400 hover:bg-yellow-500 border-4 border-yellow-500 rounded-3xl p-6 transition-all"
      >
        <Award className="w-16 h-16 text-yellow-900 mx-auto mb-3" />
        <p className="text-3xl font-bold text-yellow-900">Erfolge ansehen</p>
      </button>
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto bg-gray-50 min-h-screen flex flex-col">
      <div className="flex-1 overflow-y-auto pb-24">
        {currentView === 'home' && <HomeView />}
        {currentView === 'exercises' && <ExercisesView />}
        {currentView === 'detail' && selectedExercise && <ExerciseDetailView />}
        {currentView === 'rewards' && <RewardsView />}
        {currentView === 'cafe-map' && <CafeMapView />}
        {currentView === 'cafe-detail' && selectedCafe && <CafeDetailView />}
        {currentView === 'profile' && <ProfileView />}
      </div>

      <nav className="fixed bottom-0 left-0 right-0 max-w-2xl mx-auto bg-white border-t-4 border-gray-200">
        <div className="flex justify-around py-4">
          <button
            onClick={() => setCurrentView('home')}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-2xl transition-all ${
              currentView === 'home' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
            }`}
          >
            <Home className="w-10 h-10" />
            <span className="text-lg font-semibold">Start</span>
          </button>
          <button
            onClick={() => setCurrentView('exercises')}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-2xl transition-all ${
              currentView === 'exercises' || currentView === 'detail' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
            }`}
          >
            <BookOpen className="w-10 h-10" />
            <span className="text-lg font-semibold">Übungen</span>
          </button>
          <button
            onClick={() => setCurrentView('rewards')}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-2xl transition-all ${
              currentView === 'rewards' || currentView === 'cafe-map' || currentView === 'cafe-detail' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
            }`}
          >
            <Gift className="w-10 h-10" />
            <span className="text-lg font-semibold">Belohnungen</span>
          </button>
          <button
            onClick={() => setCurrentView('profile')}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-2xl transition-all ${
              currentView === 'profile' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
            }`}
          >
            <User className="w-10 h-10" />
            <span className="text-lg font-semibold">Profil</span>
          </button>
        </div>
      </nav>

      {showEmergency && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
          <div className="bg-white rounded-3xl p-8 max-w-lg w-full">
            <h2 className="text-4xl font-bold text-red-600 mb-6 text-center">NOTFALL</h2>
            <button className="w-full bg-red-500 hover:bg-red-600 text-white text-2xl font-bold py-6 rounded-2xl mb-4">
              <Phone className="w-8 h-8 inline mr-3" />
              112 - Notruf
            </button>
            <button
              onClick={() => setShowEmergency(false)}
              className="w-full bg-gray-300 hover:bg-gray-400 text-gray-800 text-2xl font-bold py-5 rounded-2xl"
            >
              Abbrechen
            </button>
          </div>
        </div>
      )}

      {showVideoCall && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
          <div className="bg-white rounded-3xl p-8 max-w-lg w-full">
            <h2 className="text-4xl font-bold text-green-600 mb-6 text-center">Video-Anruf</h2>
            <p className="text-2xl text-center mb-6">Familie anrufen</p>
            <button
              onClick={() => setShowVideoCall(false)}
              className="w-full bg-gray-300 hover:bg-gray-400 text-gray-800 text-2xl font-bold py-5 rounded-2xl"
            >
              Schließen
            </button>
          </div>
        </div>
      )}

      {showAchievements && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-4xl font-bold text-yellow-600 mb-6 text-center">Ihre Erfolge</h2>
            
            <div className="space-y-4 mb-6">
              {achievements.map(achievement => (
                <div 
                  key={achievement.id} 
                  className={`rounded-3xl p-6 border-4 ${
                    achievement.unlocked 
                      ? 'bg-gradient-to-br from-yellow-100 to-orange-100 border-yellow-400' 
                      : 'bg-gray-100 border-gray-300 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <span className="text-6xl">{achievement.icon}</span>
                    <div>
                      <p className="text-2xl font-bold text-gray-800">{achievement.title}</p>
                      <p className="text-lg text-gray-600">{achievement.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <button
              onClick={() => setShowAchievements(false)}
              className="w-full bg-gray-300 hover:bg-gray-400 text-gray-800 text-2xl font-bold py-5 rounded-2xl"
            >
              Schließen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}